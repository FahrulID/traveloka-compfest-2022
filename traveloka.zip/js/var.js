var width = 768
var height = 1280
var maxPassenger = 20
var timer = 60 * 2000; // 60 * 1000 = 1 menit

export {width, height, maxPassenger, timer};