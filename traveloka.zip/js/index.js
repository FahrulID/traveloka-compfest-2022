import {config} from './config.js';

var game = new Phaser.Game(config);